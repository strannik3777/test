#!/usr/bin/env bash

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
. $SCRIPT_DIR/h-manifest.conf

uptime=$(( `date +%s` - `stat -c %Y $CUSTOM_CONFIG_FILENAME` ))

#Compile stats/khs
stats=$(jq -nc \
        --arg ver "$CUSTOM_VERSION" \
        --arg uptime "$uptime" \
        '{ algo : "RRC", ver:$ver , $uptime}')

echo Debug info:
echo Output : $stats

[[ -z $stats ]] && stats="null"
