#!/usr/bin/env bash
# MMPOS agent stats script. This file is used to fetch stats from custom miners or miners without natively added API.
# Only this file is relevant for agent. If you have additional scripts, include them here.
# MMPOS agent will call that script regularly when collecting stats.
cd `dirname $0`
API_TIMEOUT=120
stats_raw=`curl --connect-timeout 2 --max-time $API_TIMEOUT --silent --noproxy '*' http://127.0.0.1:3001`
get_miner_stats() {
    local miner_name=$(echo $stats_raw |jq -c -r ".name")
    local miner_version=$(echo $stats_raw | jq -c -r ".version")
    local busid=$(echo $stats_raw | jq -r ".devices[].bus_id" |  jq -sc .)
    local ac=$(echo $stats_raw | jq -c -r ".algos[].total_accepted_shares")
    local inv=$(echo $stats_raw | jq -c -r ".algos[].total_rejected_shares")
    local hash=$(echo $stats_raw | jq -c -r ".algos[].hashrates")
    local units="hs"

    stats=$(jq --arg ac "$ac" --arg inv "$inv" \
            --argjson busid "$busid" --argjson hash "$hash" \
            --arg units "$units" \
            --arg miner_version "$miner_version" \
            --arg miner_name "$miner_name" \
        '{busid: $busid, hash: $hash, $units, ar: [$ac, $inv], $miner_version, $miner_name}' <<< "$stats_raw")
    echo $stats
}
get_miner_stats