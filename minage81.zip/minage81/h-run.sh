#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
. $SCRIPT_DIR/h-manifest.conf
echo "> install dependencies"
$SCRIPT_DIR/install.sh
echo "> dependencies installed"

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1

# Определяем количество GPU (заменили gpu-detect на кросс-платформенное решение)
if [ -z "$gpu_count" ]; then
    if command -v nvidia-smi &> /dev/null; then
        gpu_count=$(nvidia-smi -L | wc -l)
    else
        gpu_count=$(lspci | grep -i 'VGA\|3D\|Display' | grep -i 'NVIDIA\|AMD\|Radeon' | wc -l)
        [ "$gpu_count" -eq 0 ] && gpu_count=1  # Если не нашли GPU, предполагаем 1
    fi
fi

$LINE
echo -e "${GREEN}> Starting custom miner:${WHITE}"

MY_PID=$$
echo "> using ${gpu_count} gpus"
map=("0x1" "0x2" "0x4" "0x8" "0x10" "0x20" "0x40" "0x80" "0x100" "0x200" "0x400" "0x800" "0x1000" "0x2000" "0x4000" "0x8000")

# Создаем директорию для логов, если её нет
mkdir -p /var/log/miner_logs
chmod 777 /var/log/miner_logs

for ((i = 0; i < gpu_count; i++)); do
  screenName="${CUSTOM_MINERBIN}$i"
  apiPort=$((44440 + i))
  log="/var/log/miner_logs/${CUSTOM_MINERBIN}$i.log"
  
  # Проверяем существование бинарника
  if [ ! -f "./${CUSTOM_MINERBIN}" ]; then
      echo -e "${RED}Miner binary ${CUSTOM_MINERBIN} not found!${NOCOLOR}"
      exit 1
  fi

  batch="CUDA_VISIBLE_DEVICES=$i ./${CUSTOM_MINERBIN} $(< ${CUSTOM_CONFIG_FILENAME}) -t 4 --cpu-affinity ${map[i]} --api-bind $apiPort"

  fullBatch=$(cat <<EOF
(
  ( while kill -0 $MY_PID 2>/dev/null; do sleep 1; done
    echo "GPU $i: parent died, shutting down miner..."
    kill \$\$ ) &

  while true; do 
    $batch 2>&1 | tee -a $log
    sleep 1  # Задержка перед перезапуском, если майнер упадет
  done
)
EOF
)

  echo -e "${GREEN}Starting GPU $i:${NOCOLOR} $batch"
  
  # Убиваем старый screen, если есть
  if command -v screen &> /dev/null; then
      screen -S "$screenName" -X quit &> /dev/null
      screen -dmS "$screenName" bash -c "$fullBatch"
  else
      echo -e "${YELLOW}Screen not found, running in background${NOCOLOR}"
      nohup bash -c "$fullBatch" &> "$log" &
  fi
done

echo -e "${GREEN}All miners started. Use 'screen -ls' to view running miners.${NOCOLOR}"
echo -e "${GREEN}Logs are being written to /var/log/miner_logs/${CUSTOM_MINERBIN}*.log${NOCOLOR}"

# Бесконечное ожидание (можно закомментировать, если запускается как сервис)
while true; do sleep 3600; done