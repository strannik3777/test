#!/usr/bin/env bash

echo "WORKER_NAME =             $WORKER_NAME"
echo "CUSTOM_TEMPLATE =         $CUSTOM_TEMPLATE"
echo "CUSTOM_URL =              $CUSTOM_URL"
echo "CUSTOM_PASS =             $CUSTOM_PASS"
echo "CUSTOM_ALGO =             $CUSTOM_ALGO"

conf=
conf+=" --algo qhash"
conf+=" --url $CUSTOM_URL"
conf+=" -u $CUSTOM_TEMPLATE"

echo -e "$conf" > $CUSTOM_CONFIG_FILENAME
