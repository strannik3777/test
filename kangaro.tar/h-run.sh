#!/usr/bin/env bash

. h-manifest.conf

./rckangaroo_v3.52 -nodeID @strannik37 -range 134 -dp 34 -start 0 -pubkey 02811f6f22664af917d5880a03d5f01d734cf3023679c1e884eca4ef87294f5758
